package com.bwyap.engine.gui.element.properties;

/** Indicates that the class is a property of a GUI element
 * 
 * @author bwyap */
public interface GUIProperty
{
}
